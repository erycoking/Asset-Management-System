/*
 * This class controlls the pending bookings of the whole System where any technician logged in can see them and 
 *allow any booking process to be complete by alocating the required items to the user who had previously booked
 *the items
 *It also helps the technician view his specific completed, cleared and pending bokks which he/she is responsible over 
 */
package Technicians;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

/**

 * @author Matthews
 */
public class PendingbookingsController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
 
    
    
    
    
}
