/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lams;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.TilePane;
import lams.Equipments.Equipments;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import views.Availablelequipments;
import views.BooklayoutController;
//import views.booklayout.fxml;

/**
 *
 * @author Matthews
 */
public class HomeController implements Initializable {

    private Label label;
    @FXML
    private Button button;
    private TextArea textarea;
    private Label labelcost;
    @FXML
    private Button btnbook;
    @FXML
    private Button imageshow;
    @FXML
    private Button button1;
    @FXML
    private JFXTextField txtusername;
    @FXML
    private JFXPasswordField txtpassword;
    @FXML
    private Label dialoguelabel;

    @FXML
    private void handleButtonAction(ActionEvent event) {
       try {
            System.out.println("You clicked me!");
            label.setText("Hello World!");
            //Create a connection to the database
            dbconnection dc = new dbconnection();
            Connection conn = dc.ConnectDB();
            String sql = "select * from unbookedeqpmnts";

            //System.out.println(" my username "+user);
            PreparedStatement pst;
            ResultSet rs;
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                textarea.appendText("Equipment Name" + rs.getString(2) + "\n cost:\n" + rs.getString(3) + "\n \n");
                Label labe1 = new Label("We are one");
                //GridPane gridpane=new GridPane();
                //gridpane.add(labe1,117,319);

                for (int r = 0; r < 5; r++) {
                    for (int c = 0; c < 4; c++) {
                        int number = 5 * r + c;
                        String n = String.valueOf(number);
                        Button button2 = new Button(String.valueOf(number));
                        Label labelnamee = new Label();
                        button2.setId(n);
                        labelnamee.setText(rs.getString(2));
                        labelcost.setText(rs.getString(3));
                        btnbook.setVisible(true);
                        double x = 90;
                        button2.setLayoutX(x);
                        button2.setLayoutY(450.0);
                        //button.setText("Say 'Hello World buttton'");

                        //grid.add(button, c, r);
                        x = x + 30;
                    }

                }
            }
            /*Equipments eq = new Equipments();
            eq.Addequipment();*/
            label.setText("sucess");

        } catch (SQLException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    /*****************************************************************************************************/
    /* This method sets the Tile pane with images of the available equipments from the database*/
     /*****************************************************************************************************/

    public void view() {
        TilePane tile = new TilePane();//create the tilepane layout
        tile.setPadding(new Insets(15, 15, 15, 15));
        tile.setHgap(15);
        String path = "F:\\phone\\image";

        File folder = new File(path);
        File[] listOfFiles = folder.listFiles();

        for (final File file : listOfFiles) {
            ImageView imageView;
            imageView = createImageView(file);
            tile.getChildren().addAll(imageView);
        }
    }
   /*****************************************************************************************************/
    //Method to help in creating a new imageview each time we have a new imagefile
    /*****************************************************************************************************/
    public ImageView createImageView(final File imageFile) {
        ImageView imageView = null;
        try {
            final Image image = new Image(new FileInputStream(imageFile), 150, 0, true,
                    true);
            imageView = new ImageView(image);
            imageView.setFitWidth(150);
        } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            }
        return imageView;
    }
    @FXML
    public void showavailable() throws IOException{
    
        Availablelequipments av=new  Availablelequipments();
        //this is the method in the available equipments class that dispalys the images available in the file
        av.display();
    }
    /*****************************************************************************************************/
    // The method displayavailabes() handles the loging in to the system after writing in the login details
    //********************************************************************************************************/
    @FXML
    public void displayavailabes() throws IOException, SQLException{
        dbconnection db;
        db = new dbconnection();
            PreparedStatement ps;
            Connection conn = db.ConnectDB();
        //txtusername.onKeyTypedProperty();
       // String query="SELECT * FROM asm.login where username='adminn' && password='th95matttt'";
        ResultSet rs=conn.createStatement().executeQuery("SELECT * FROM asm.login where username='"+txtusername.getText()+"' && password='"+txtpassword.getText()+"'");
        if(rs.next()){
            //If there exists such a user the following is executed.
        BooklayoutController bk= new BooklayoutController();
        //method showstagetable is only shown if there are such credentials
        bk.showstagetable();
    }
        else{
        System.out.println("THE credentials does not exist");
        dialoguelabel.setText("Please ensure you have written down your correct login details correctly");
        if(txtusername.getText().equals("") && txtpassword.getText().equals("")){
            System.out.println("Please ensure you have written down your correct login details correctly");
            dialoguelabel.setText("Please ensure you have entered your correct login details correctly");
        }
        }
    
    }
}
