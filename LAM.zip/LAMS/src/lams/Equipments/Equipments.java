/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lams.Equipments;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import lams.dbconnection;

/**
 *
 * @author Matthews
 */
public class Equipments {

    private int id;
    private int quantity;
    private int cost;
    private String Name;
    private String Details;
    private String image;

    public Equipments(int id, int quantity, int cost, String Name, String Details) {
        this.id = id;
        this.quantity = quantity;
        this.cost = cost;
        this.Name = Name;
        this.Details = Details;
    }

    public Equipments() {
       
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public String getName() {
        return Name;
    }
     public String image() {
        return image;
    }
     public void setimage(String image) {
        this.image = image;
    }
    public void setName(String Name) {
        this.Name = Name;
    }

    public String getDetails() {
        return Details;
    }

    public void setDetails(String Details) {
        this.Details = Details;
    }
}
