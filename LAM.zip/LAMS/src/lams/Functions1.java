/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lams;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.Border;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;
import views.BooklayoutController;

/**
 *
 * @author Matthews
 */
public class Functions1 {
    
    
    public void showimagesavailabe() throws FileNotFoundException{
    
        try {
             Stage stage=new Stage();
            AnchorPane root = new AnchorPane();
            TilePane sp = new TilePane();
            sp.setPadding(new Insets(5, 5, 5, 5));
            //sp.setHgap(15);
            
            sp.setLayoutY(0);
            sp.setLayoutX(5);
            String path = "image";
            
            File folder = new File(path);
            File[] listOfFiles = folder.listFiles();
            
            for (final File file : listOfFiles) {
                //Image img = new Image(file.toURI().toString());
                
                final Image image = new Image(new FileInputStream(file));
                //150, 0, true,true);
                ImageView imgView = new ImageView(image);
                imgView.setFitHeight(100);
                imgView.setFitWidth(150);
                int number = 5 ;
                int xv=0;
                int yv=6;
                String n = String.valueOf(number);
                Button button = new Button(String.valueOf(number));
                button.setLayoutX(xv);
                button.setLayoutY(yv);
                Label label=new Label(String.valueOf(number));
                label.setId(n);
                
                button.setId(n);
                double x = 90;
                //button.setLayoutX(x);
                //button.setLayoutY(450.0);
                label.setText("book now");
                button.setText("Say "+number);
                /* comment this shld not display in the first page but in the view page*/
                sp.getChildren().add(imgView);
                sp.getChildren().add(button);
                sp.getChildren().add(label);
               // grid.add(button, c, r);

                
                number++;
                xv=xv+10;
                
            }
            
            Scene scene = new Scene(root, 300, 250);
            
            root = FXMLLoader.load(getClass().getResource("Index.fxml"));
            root.setStyle("-fx-background-color: #fb8c00");
            //root.setBackground(Background.EMPTY);
            //root.setBorder(Border.red);
            root.getChildren().add(sp);
            
            scene = new Scene(root);
           
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(Functions1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void bookitem(int eqpId, int qntty){
    /*checks the id and  removes that item from unbooked eqpmnts db then puts 
        the item into booked db and qtty booked too.. then updates the unbooked 
        db qtty field by reducing by ordered amount 
        */    
    
    }
    
}
