/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import com.jfoenix.controls.JFXTextField;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import lams.dbconnection;

/**
 
 * @author Matthews
 */
public class AddequipmentsController implements Initializable {

    @FXML
    private JFXTextField eqpname;
    @FXML
    private JFXTextField eqpquantity;
    @FXML
    private JFXTextField eqpcategory;
    @FXML
    private JFXTextField eqpdetails;
    @FXML
    private ImageView image;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
    } 
    /**
     * This method add equipment takes the specific users specified details and add that equipment into both Equipments  
     * and UnbookedEquipments.
     
     */
    @FXML
    private void addequipment(ActionEvent event) {
        try {
            //Create a connection to the database
            dbconnection dc;
            dc = new dbconnection();
            Connection conn = dc.ConnectDB();
            PreparedStatement pst;
            
            String insert="INSERT INTO EQUIPMENTS (eqpname, eqpcost,image, eqpdetails, quantity,eqpcategory,date_created) VALUES('"+eqpname.getText()+"',  10000, '../images/cro.jpg', '"+eqpdetails.getText()+"','"+eqpquantity.getText()+"','"+eqpcategory.getText()+"',SYSDATE())" ;
            pst = conn.prepareStatement(insert);   
            pst.execute();
            
            PreparedStatement pst2;
            String insert2="INSERT INTO UNBOOKEDEqPMNTS  (eqpname, eqpcost,image, eqpdetails, quantity,eqpcategory,date_created) VALUES('"+eqpname.getText()+"',  10000, '../images/cro.jpg', '"+eqpdetails.getText()+"','"+eqpquantity.getText()+"','"+eqpcategory.getText()+"',SYSDATE())" ;
            pst2 = conn.prepareStatement(insert2); 
            pst2.execute();
            conn.close();
            JOptionPane.showMessageDialog(null, "Successfully added '+eqpname.getText()+'The equipment", "Add Equipment", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(AddequipmentsController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void selectimage(ActionEvent event) {
         Stage fileChooserStage = new Stage();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select an Image");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image", "*.png", "*.jpg", "*.gif"));
        File file = fileChooser.showSaveDialog(fileChooserStage);
        if (file != null) {
            String imagepath = file.getPath();
            System.out.println("file:" + imagepath);
            try {
                file.createNewFile();
            } catch (IOException ex) {
                Logger.getLogger(BooklayoutController.class.getName()).log(Level.SEVERE, null, ex);
            }
            File folder = new File("Paths");
            folder.mkdir();
            folder=new File(file.getName());
            System.out.println("filename"+file.getName());
            //ImageView imageView = new ImageView();
            //String img=file.getName();
             Image images = new Image(file.toURI().toString());
             image.setStyle("-fx-background-color: BLACK");
             /*try {
                 File f = new File("E:\\web\\LAMS\\Paths");
                 ImageIO.write((RenderedImage) images, "jpg", f);
             } catch (IOException ex) {
                 Logger.getLogger(AddequipmentsController.class.getName()).log(Level.SEVERE, null, ex);
             }*/
            //.write(images,imagepath,folder);
            //imageView.setImage(images);
            //Image images = new Image(imagepath);
            image.setImage(images);
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText("Please Select a File");
            /*alert.setContentText("You didn't select a file!");*/
            alert.showAndWait();
        }
    }
    
    
    
}
