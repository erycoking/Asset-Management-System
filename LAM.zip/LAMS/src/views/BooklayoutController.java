/*
*This is the booking controller class
 *This class displays the available equipments in a table form and helps in booking
 */
package views;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter.Change;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import lams.Functions1;
import lams.dbconnection;

/**
 
 *
 * @author Matthews
 */
public class BooklayoutController implements Initializable {

    private ObservableList<Availabledetails> data;
    @FXML
    private TableView<Availabledetails> tableitems;
    @FXML
    private TableColumn<Availabledetails, String> columnEquipments;
    @FXML
    private TableColumn<Availabledetails, String> columnType;
    @FXML
    private TableColumn<Availabledetails, String> columnquantity;
    @FXML
    private TableColumn<Availabledetails, String> columnavailable;
    @FXML
    private TextField txfdequipment;
    @FXML
    private TextField txfdcategory;
    @FXML
    private TextField txfdquantity;
    @FXML
    private TextField txfdavailable;
    @FXML
    private Button view;
    @FXML
    private Button bookeqpmnt;
    @FXML
    private Button chooseimage;
    @FXML
    private ImageView image;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    /*This method  loads data into the table view from the database*/
    @FXML
    public void loaddatafromdatabase() throws SQLException, IOException {

        dbconnection dc;
        dc = new dbconnection();
        Connection conn = dc.ConnectDB();
        data = FXCollections.observableArrayList();
        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM unbookedeqpmnts");
        while (rs.next()) {
            if (rs.getInt(6) >= 1) {
                data.add(new Availabledetails(rs.getString(2), rs.getString(7), rs.getInt(6), rs.getString(8), rs.getInt(1)));
            }

        }

        columnEquipments.setCellValueFactory(new PropertyValueFactory<>("Equipment"));
        columnType.setCellValueFactory(new PropertyValueFactory<>("Type"));
        columnquantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        columnavailable.setCellValueFactory(new PropertyValueFactory<>("Available"));
        tableitems.setItems(null);
        tableitems.setItems(data);
        //***********************************************************************************************************************
        FXMLLoader fxmlLoader2 = new FXMLLoader(getClass().getResource("Addequipments.fxml"));
            Parent root2 = (Parent) fxmlLoader2.load();
            Stage stage2 = new Stage();
            stage2.setTitle("Administrator Only");
            stage2.setScene(new Scene(root2));
            stage2.show();
        //***********************************************************************************************************************
        /*
        -----
        SHOWS A SAMPLE CODE FOR SINGLE CELL CLICKING
        int row= tableitems.getSelectedRow();
            String table_click= tableitems.getModel().getValueAt(row, 0).toString();
         */

 /*        tableitems.getSelectionModel().setCellSelectionEnabled(true);
        tableitems.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
ObservableList selectedCells = tableitems.getSelectionModel().getSelectedCells();
int selectedrow = tableitems.getSelectionModel().getSelectedIndex();

selectedCells.addListener(new ListChangeListener() {
    @Override
    public void onChanged(Change c) {
        TablePosition tablePosition = (TablePosition) selectedCells.get(0);
        Object val = tablePosition.getTableColumn().getCellData(tablePosition.getRow());
        Object val2 = tablePosition.getRow();
         
        System.out.println("Selected Value" + val);
        System.out.println("Selected row" + val2+val2.toString()+selectedrow);
    }
});*/
    }
    
    /* This method is called from the home controller to set or call the bookinglayout interface*/

    public void showstagetable() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("booklayout.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("These Are the Available Equipments");
            stage.setScene(new Scene(root1));
            stage.show();
            
        } catch (IOException ex) {
            Logger.getLogger(Functions1.class.getName()).log(Level.SEVERE, null, ex);

        }

    }

    /**
     * This method sets the text field to the value of the related item clicked in the table view for easy booking
     */
    @FXML
    private void loadvalues(MouseEvent event) throws FileNotFoundException {
        
            Availabledetails eqp = tableitems.getSelectionModel().getSelectedItem();
            System.out.println(tableitems.getItems());
            String eqpment = eqp.getEquipment();
            txfdequipment.setText(eqpment);
            txfdcategory.setText(eqp.getType());
            System.out.println("the id clicked is"+ eqp.getId() );
            Integer identity=eqp.getId();
            //*******************************************************************************************//
            //Modify this code if you have to use/view the image of the item clicked for booking in the available equipments  
            //To load the image of the equipment clicked on the table using the Equipment ID
            //******************************************************************************************//
            /*dbconnection  dc = new dbconnection();
            PreparedStatement ps;
            Connection conn = dc.ConnectDB();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM equipments ");
            //SELECT image FROM asm.equipments where eqpID=2;
            //String filepath=rs.getString(4);
            System.out.println("the path clicked is"+ rs.getString(4));*/
            /*Stage fileChooserStage = new Stage();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select an Image");
        fileChooser.getExtensionFilters().add(new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
            */
       
            /*File file = new File(filepath);
        if (file != null) {
            String imagepath = file.getPath();
            System.out.println("file:" + imagepath);
            //ImageView imageView = new ImageView();
             Image images = new Image(new FileInputStream(imagepath));
             image.setStyle("-fx-background-color: BLACK");
            //imageView.setImage(images);
            //Image images = new Image(imagepath);
            image.setImage(images);
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText("Please Select a File");
            /*alert.setContentText("You didn't select a file!");
            alert.showAndWait();
        }
        */
            // person.
            
            // String add = String.parseString(txfdquantity.getText());
            txfdquantity.setText(eqp.getQuantity().toString());
            //txfdavailable.setText( person.getId());
        

    }
    /**
     * This is the method that books the selected item/equipments does the calculations
     * for the equipments quantity and time
     */
    
    @FXML
    private void bookitem(ActionEvent event) {
        try {
            //make a connection to the database
            dbconnection dc;
            dc = new dbconnection();
            PreparedStatement ps;
            Connection conn = dc.ConnectDB();
            //get the selected table's model item
            Availabledetails available = tableitems.getSelectionModel().getSelectedItem();
            //get the enetered valueof the from time.
            String fromtime = txfdavailable.getText();
            String inserting = " INSERT INTO bookedeqpmnts (`eqpID`, `quantity`, `Fromdate_time`,`Todate_time`)VALUES('" + available.getId() + "','" + txfdquantity.getText() + "','" + fromtime + "','April 7, 2017 5:49:pm')";

            ps = conn.prepareStatement(inserting);
            ps.execute();
            //String delete="DELETE FROM bookedeqpmnts WHERE eqpID=1";
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM unbookedeqpmnts where eqpID='" + available.getId() + "'");
            //reduces the equipment quantity by the number of  equipments ordered 
            Integer ordered = Integer.parseInt(txfdquantity.getText());
            int remaining = 0;

            while (rs.next()) {
                //calculate the remaining eqpments and set the variable for updating the database
                remaining = rs.getInt(6) - ordered;

            }
            System.out.println("remainders" + remaining);
            available.setQuantity(remaining);
            //update the database for the order 
            String Update = "UPDATE unbookedeqpmnts SET quantity='" + remaining + "' Where eqpID='" + available.getId() + "'";
            ps = conn.prepareStatement(Update);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(BooklayoutController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void selectimage(ActionEvent event)  {
        //the file chooser below should be used in adding an equipmentso that we save the image path to the db
       
    }
}
